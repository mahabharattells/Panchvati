Shree Kalaram Mandir AAA 3D — How to Build Your .APK
====================================================
1. Unzip kalaram_aaa_android_project.zip and open the folder in Android Studio.
2. Wait for Gradle sync to finish.
3. Click Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. Copy app/build/outputs/apk/debug/app-debug.apk to your Android phone and install!
