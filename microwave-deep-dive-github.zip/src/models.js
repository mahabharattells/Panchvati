// High-Detail Deep Dive 3D Model Library for "How You Accidentally Reinvented the Modern Microwave Oven"
// Tuned for crisp PBR contrast, rich midnight lighting, razor-sharp X-ray cutaways, and zero bloom washout.
import * as THREE from 'three';
import { lightRig } from './core/engine.js';
import { xrayMaterial } from './core/sets.js';

const std = (color, roughness = 0.5, extra = {}) =>
  new THREE.MeshStandardMaterial({ color, roughness, ...extra });
const phys = (color, roughness = 0.25, extra = {}) =>
  new THREE.MeshPhysicalMaterial({ color, roughness, ...extra });
const shadowed = (m) => { m.castShadow = true; m.receiveShadow = true; return m; };

export function canvasTex(w, h, draw, rep = [1, 1]) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(...rep);
  t.anisotropy = 8;
  return t;
}

// ── Shared Procedural Textures ─────────────────────────────────────────────
function brushedMetalTex(base = '#9BA5B2') {
  return canvasTex(512, 512, (g, w, h) => {
    g.fillStyle = base;
    g.fillRect(0, 0, w, h);
    for (let y = 0; y < h; y += 2) {
      const a = 0.04 + ((y * 37) % 13) * 0.006;
      g.fillStyle = y % 4 === 0 ? `rgba(255,255,255,${a})` : `rgba(15,20,30,${a})`;
      g.fillRect(0, y, w, 1.5);
    }
  }, [2, 2]);
}

function controlPanelTex() {
  return canvasTex(512, 1024, (g, w, h) => {
    g.fillStyle = '#0A0C10';
    g.fillRect(0, 0, w, h);
    g.strokeStyle = '#252C38';
    g.lineWidth = 8;
    g.strokeRect(12, 12, w - 24, h - 24);
    // Crisp cyan LED display
    g.fillStyle = '#031018';
    g.beginPath(); g.roundRect(40, 56, w - 80, 156, 16); g.fill();
    g.strokeStyle = '#1C4B60'; g.lineWidth = 4; g.stroke();
    g.fillStyle = '#4FF0FF';
    g.shadowColor = '#1CC8F0'; g.shadowBlur = 14;
    g.font = '900 88px monospace'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText('01:30', w / 2, 126);
    g.shadowBlur = 0;
    g.fillStyle = '#45C4DC';
    g.font = '700 22px sans-serif';
    g.fillText('2.45 GHz  •  HIGH', w / 2, 184);
    // Keypad 3x4
    const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'STOP', '0', 'START'];
    for (let i = 0; i < 12; i++) {
      const col = i % 3, row = Math.floor(i / 3);
      const bx = 46 + col * 144, by = 270 + row * 124;
      const isStart = keys[i] === 'START', isStop = keys[i] === 'STOP';
      g.fillStyle = isStart ? '#0D3328' : isStop ? '#361318' : '#141922';
      g.beginPath(); g.roundRect(bx, by, 126, 98, 14); g.fill();
      g.strokeStyle = isStart ? '#32C98A' : isStop ? '#EE5260' : '#2C3444';
      g.lineWidth = 3; g.stroke();
      g.fillStyle = isStart ? '#76EDB2' : isStop ? '#FF828C' : '#D2DCE8';
      g.font = (isStart || isStop) ? '800 26px sans-serif' : '800 42px sans-serif';
      g.fillText(keys[i], bx + 63, by + 51);
    }
    // Bottom door-release bar
    g.fillStyle = '#1B212C';
    g.beginPath(); g.roundRect(56, 820, w - 112, 110, 20); g.fill();
    g.strokeStyle = '#4A5568'; g.lineWidth = 4; g.stroke();
    g.fillStyle = '#A8B3C4'; g.font = '700 28px sans-serif';
    g.fillText('PUSH OPEN', w / 2, 878);
  });
}

function faradayMeshTex() {
  return canvasTex(512, 512, (g, w, h) => {
    g.fillStyle = '#0D1118';
    g.fillRect(0, 0, w, h);
    g.globalCompositeOperation = 'destination-out';
    const step = 16;
    for (let y = 8; y < h; y += step) {
      const off = ((y / step) % 2) * (step / 2);
      for (let x = 8; x < w; x += step) {
        g.beginPath();
        g.arc((x + off) % w, y, 4.8, 0, Math.PI * 2);
        g.fill();
      }
    }
  }, [5, 3]);
}

function subwayTileTex() {
  return canvasTex(512, 512, (g, w, h) => {
    g.fillStyle = '#111720';
    g.fillRect(0, 0, w, h);
    const rows = 8, cols = 4, rh = h / rows, cw = w / cols;
    for (let r = 0; r < rows; r++) {
      const shift = (r % 2) * (cw * 0.5);
      for (let c = -1; c <= cols; c++) {
        const shade = 26 + ((r * 13 + c * 29) % 8);
        g.fillStyle = `rgb(${shade}, ${shade + 6}, ${shade + 14})`;
        g.fillRect(c * cw + shift + 3, r * rh + 3, cw - 6, rh - 6);
      }
    }
  }, [5, 2.5]);
}

// ── 1. LEFTOVER PASTA BOWL (saturated, crisp hot/cold contrast) ────────────
export function createPastaBowl() {
  const g = new THREE.Group();
  const pts = [
    new THREE.Vector2(0.0, 0.0),
    new THREE.Vector2(0.075, 0.0),
    new THREE.Vector2(0.115, 0.025),
    new THREE.Vector2(0.138, 0.068),
    new THREE.Vector2(0.142, 0.072),
    new THREE.Vector2(0.132, 0.072),
    new THREE.Vector2(0.105, 0.028),
    new THREE.Vector2(0.068, 0.008),
    new THREE.Vector2(0.0, 0.008),
  ];
  const bowlMat = phys('#D8D3C8', 0.22, { clearcoat: 0.75, clearcoatRoughness: 0.16 });
  const bowl = shadowed(new THREE.Mesh(new THREE.LatheGeometry(pts, 40), bowlMat));
  g.add(bowl);

  // Split left/right sauce mound
  const leftMat = phys('#B53420', 0.38, { clearcoat: 0.45, emissive: '#D62810', emissiveIntensity: 0 });
  const rightMat = phys('#B53420', 0.38, { clearcoat: 0.45, emissive: '#1D8FE1', emissiveIntensity: 0 });

  const leftMound = new THREE.Mesh(
    new THREE.SphereGeometry(0.11, 24, 16, Math.PI * 0.5, Math.PI, 0, Math.PI * 0.48),
    rightMat
  );
  leftMound.scale.set(1, 0.38, 1); leftMound.position.y = 0.024;
  const rightMound = new THREE.Mesh(
    new THREE.SphereGeometry(0.11, 24, 16, -Math.PI * 0.5, Math.PI, 0, Math.PI * 0.48),
    leftMat
  );
  rightMound.scale.set(1, 0.38, 1); rightMound.position.y = 0.024;
  g.add(leftMound, rightMound);

  // Pasta swirls
  const noodleMatL = phys('#D9B266', 0.42, { clearcoat: 0.3, emissive: '#E03C14', emissiveIntensity: 0 });
  const noodleMatR = phys('#D9B266', 0.42, { clearcoat: 0.3, emissive: '#229CE8', emissiveIntensity: 0 });
  for (let i = 0; i < 18; i++) {
    const ang = (i / 18) * Math.PI * 2;
    const rad = 0.028 + (i % 3) * 0.028;
    const x = Math.cos(ang) * rad, z = Math.sin(ang) * rad;
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(x - 0.022, 0.052, z - 0.01),
      new THREE.Vector3(x, 0.068 + (i % 2) * 0.008, z + 0.008),
      new THREE.Vector3(x + 0.022, 0.050, z - 0.006),
    ]);
    const isLeft = x < 0;
    const m = new THREE.Mesh(new THREE.TubeGeometry(curve, 12, 0.0095, 8, false), isLeft ? noodleMatL : noodleMatR);
    m.rotation.y = ang * 1.3;
    g.add(m);
  }

  // Basil leaves
  const basilMat = std('#256D2B', 0.48);
  for (let i = 0; i < 4; i++) {
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.015, 10, 8), basilMat);
    b.scale.set(1.4, 0.18, 0.85);
    b.position.set(Math.cos(i * 1.7) * 0.04, 0.072, Math.sin(i * 1.7) * 0.04);
    b.rotation.set(0.2, i * 1.2, 0.15);
    g.add(b);
  }

  // Subtle translucent steam wisps (never white-washing!)
  const steamGroup = new THREE.Group();
  const steamMat = new THREE.MeshBasicMaterial({ color: '#FFE8D6', transparent: true, opacity: 0, depthWrite: false });
  const steamRings = [];
  for (let i = 0; i < 6; i++) {
    const puff = new THREE.Mesh(new THREE.SphereGeometry(0.016 + (i % 3) * 0.005, 12, 10), steamMat);
    puff.userData = { idx: i, x0: -0.045 + (i % 3) * 0.02, z0: ((i % 3) - 1) * 0.022 };
    steamGroup.add(puff);
    steamRings.push(puff);
  }
  g.add(steamGroup);

  // Crisp faceted ice crystals on right side when frozen
  const frostGroup = new THREE.Group();
  const frostMat = phys('#7CE0FF', 0.15, { emissive: '#1EA7E1', emissiveIntensity: 0.25, transparent: true, opacity: 0 });
  for (let i = 0; i < 8; i++) {
    const cr = new THREE.Mesh(new THREE.OctahedronGeometry(0.014 + (i % 2) * 0.005, 0), frostMat);
    cr.position.set(0.032 + (i % 3) * 0.024, 0.068 + (i % 2) * 0.011, ((i % 3) - 1) * 0.028);
    cr.rotation.set(i, i * 0.7, 0.4);
    frostGroup.add(cr);
  }
  g.add(frostGroup);

  const HOT_SAUCE = new THREE.Color('#E03418'), BASE_SAUCE = new THREE.Color('#B53420'), COLD_SAUCE = new THREE.Color('#4286B5');
  const HOT_NOODLE = new THREE.Color('#F29B4B'), BASE_NOODLE = new THREE.Color('#D9B266'), COLD_NOODLE = new THREE.Color('#7EBCE0');

  return {
    group: g,
    update(t, uniformHeat = 0, splitMode = 0) {
      const hL = Math.max(uniformHeat, splitMode);
      const cR = splitMode;
      const hR = Math.max(uniformHeat * (1 - splitMode), 0);

      leftMat.color.copy(BASE_SAUCE).lerp(HOT_SAUCE, hL * 0.65);
      leftMat.emissiveIntensity = hL * 0.28;
      noodleMatL.color.copy(BASE_NOODLE).lerp(HOT_NOODLE, hL * 0.5);
      noodleMatL.emissiveIntensity = hL * 0.22;

      rightMat.color.copy(BASE_SAUCE).lerp(COLD_SAUCE, cR * 0.85).lerp(HOT_SAUCE, hR * 0.65);
      rightMat.emissive.set(cR > 0.1 ? '#1B8EE0' : '#D62810');
      rightMat.emissiveIntensity = cR > 0.1 ? cR * 0.28 : hR * 0.28;
      noodleMatR.color.copy(BASE_NOODLE).lerp(COLD_NOODLE, cR * 0.85).lerp(HOT_NOODLE, hR * 0.5);
      noodleMatR.emissive.set(cR > 0.1 ? '#38B8F0' : '#E03C14');
      noodleMatR.emissiveIntensity = cR > 0.1 ? cR * 0.22 : hR * 0.22;

      const steamAmp = Math.max(uniformHeat, splitMode * 0.85);
      steamMat.opacity = steamAmp * 0.16;
      steamRings.forEach((p, i) => {
        const ph = (t * 0.75 + i * 0.21) % 1;
        const xSpread = splitMode > 0.2 ? -0.052 + (i % 3) * 0.015 : (p.userData.x0 * 1.4);
        p.position.set(xSpread + Math.sin(t * 2.5 + i) * 0.01, 0.075 + ph * 0.14, p.userData.z0);
        p.scale.setScalar(0.6 + ph * 1.1);
      });
      frostMat.opacity = splitMode * 0.85;
      frostGroup.visible = splitMode > 0.05;
    },
  };
}

// ── 2. HERO MODERN STAINLESS-STEEL MICROWAVE ───────────────────────────────
export function createHeroMicrowave() {
  const g = new THREE.Group();
  const W_MIC = 0.54, H_MIC = 0.32, D_MIC = 0.38;
  const steelTex = brushedMetalTex('#9EA8B4');
  const steelMat = phys('#AEB8C4', 0.30, { metalness: 0.84, map: steelTex, clearcoat: 0.3 });
  const darkTrim = phys('#12161E', 0.25, { metalness: 0.35, clearcoat: 0.75 });
  const enamelMat = phys('#CDD5DF', 0.28, { metalness: 0.12, clearcoat: 0.4 });

  const shell = new THREE.Group();
  const thick = 0.018;
  const topP = shadowed(new THREE.Mesh(new THREE.BoxGeometry(W_MIC, thick, D_MIC), steelMat));
  topP.position.set(0, H_MIC - thick / 2, 0);
  const botP = shadowed(new THREE.Mesh(new THREE.BoxGeometry(W_MIC, thick, D_MIC), steelMat));
  botP.position.set(0, thick / 2, 0);
  const backP = shadowed(new THREE.Mesh(new THREE.BoxGeometry(W_MIC, H_MIC, thick), steelMat));
  backP.position.set(0, H_MIC / 2, -D_MIC / 2 + thick / 2);
  const leftP = shadowed(new THREE.Mesh(new THREE.BoxGeometry(thick, H_MIC, D_MIC), steelMat));
  leftP.position.set(-W_MIC / 2 + thick / 2, H_MIC / 2, 0);
  const rightBlock = shadowed(new THREE.Mesh(new THREE.BoxGeometry(0.13, H_MIC, D_MIC), steelMat));
  rightBlock.position.set(W_MIC / 2 - 0.065, H_MIC / 2, 0);
  shell.add(topP, botP, backP, leftP, rightBlock);

  const cavW = W_MIC - 0.13 - thick, cavH = H_MIC - thick * 2, cavD = D_MIC - thick * 1.5;
  const cavCenterX = -W_MIC / 2 + thick + cavW / 2;
  const cavBack = new THREE.Mesh(new THREE.PlaneGeometry(cavW, cavH), enamelMat);
  cavBack.position.set(cavCenterX, H_MIC / 2, -D_MIC / 2 + thick + 0.002);
  const cavLeft = new THREE.Mesh(new THREE.PlaneGeometry(cavD, cavH), enamelMat);
  cavLeft.rotation.y = Math.PI / 2; cavLeft.position.set(-W_MIC / 2 + thick + 0.002, H_MIC / 2, 0);
  const cavRight = new THREE.Mesh(new THREE.PlaneGeometry(cavD, cavH), enamelMat);
  cavRight.rotation.y = -Math.PI / 2; cavRight.position.set(W_MIC / 2 - 0.13 - 0.002, H_MIC / 2, 0);
  const cavFloor = new THREE.Mesh(new THREE.PlaneGeometry(cavW, cavD), enamelMat);
  cavFloor.rotation.x = -Math.PI / 2; cavFloor.position.set(cavCenterX, thick + 0.002, 0);
  const cavCeil = new THREE.Mesh(new THREE.PlaneGeometry(cavW, cavD), enamelMat);
  cavCeil.rotation.x = Math.PI / 2; cavCeil.position.set(cavCenterX, H_MIC - thick - 0.002, 0);
  const mica = new THREE.Mesh(new THREE.BoxGeometry(0.004, 0.11, 0.09), std('#7D8594', 0.65, { metalness: 0.25 }));
  mica.position.set(W_MIC / 2 - 0.133, H_MIC * 0.54, -0.02);
  shell.add(cavBack, cavLeft, cavRight, cavFloor, cavCeil, mica);

  const footMat = std('#101216', 0.85);
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const ft = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.025, 0.012, 16), footMat);
    ft.position.set(sx * (W_MIC / 2 - 0.05), -0.006, sz * (D_MIC / 2 - 0.05));
    shell.add(ft);
  }

  const panelTex = controlPanelTex();
  const panelMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(0.122, H_MIC - 0.016),
    new THREE.MeshStandardMaterial({ map: panelTex, emissiveMap: panelTex, emissive: '#FFFFFF', emissiveIntensity: 0.55, roughness: 0.18 })
  );
  panelMesh.position.set(W_MIC / 2 - 0.065, H_MIC / 2, D_MIC / 2 + 0.002);
  shell.add(panelMesh);
  g.add(shell);

  // Warm balanced cavity lamp (soft glow, no blowout)
  const cavityLight = new THREE.PointLight('#FFD89B', 0.42, 0.85, 1.6);
  cavityLight.position.set(cavCenterX, H_MIC - 0.04, 0.04);
  g.add(cavityLight);

  const turntablePivot = new THREE.Group();
  turntablePivot.position.set(cavCenterX, thick + 0.016, 0.01);
  const ringMat = std('#2E3440', 0.5);
  const rollerRing = new THREE.Mesh(new THREE.TorusGeometry(0.085, 0.006, 10, 32), ringMat);
  rollerRing.rotation.x = Math.PI / 2; rollerRing.position.y = -0.006;
  const glassPlateMat = phys('#B8E6FA', 0.08, { transparent: true, opacity: 0.44, clearcoat: 1 });
  const glassTray = new THREE.Mesh(new THREE.CylinderGeometry(0.145, 0.138, 0.008, 40), glassPlateMat);
  const trayRim = new THREE.Mesh(new THREE.TorusGeometry(0.145, 0.0045, 10, 40), glassPlateMat);
  trayRim.rotation.x = Math.PI / 2; trayRim.position.y = 0.003;
  turntablePivot.add(rollerRing, glassTray, trayRim);
  g.add(turntablePivot);

  const doorW = W_MIC - 0.132;
  const doorPivot = new THREE.Group();
  doorPivot.position.set(-W_MIC / 2 + 0.004, H_MIC / 2, D_MIC / 2);
  const doorGroup = new THREE.Group();
  doorGroup.position.x = doorW / 2;

  const fTop = shadowed(new THREE.Mesh(new THREE.BoxGeometry(doorW, 0.046, 0.024), darkTrim));
  fTop.position.set(0, H_MIC / 2 - 0.023, 0);
  const fBot = shadowed(new THREE.Mesh(new THREE.BoxGeometry(doorW, 0.046, 0.024), darkTrim));
  fBot.position.set(0, -H_MIC / 2 + 0.023, 0);
  const fLeft = shadowed(new THREE.Mesh(new THREE.BoxGeometry(0.044, H_MIC - 0.092, 0.024), darkTrim));
  fLeft.position.set(-doorW / 2 + 0.022, 0, 0);
  const fRight = shadowed(new THREE.Mesh(new THREE.BoxGeometry(0.044, H_MIC - 0.092, 0.024), darkTrim));
  fRight.position.set(doorW / 2 - 0.022, 0, 0);
  const sTop = new THREE.Mesh(new THREE.BoxGeometry(doorW, 0.012, 0.026), steelMat);
  sTop.position.set(0, H_MIC / 2 - 0.006, 0);
  const sBot = new THREE.Mesh(new THREE.BoxGeometry(doorW, 0.012, 0.026), steelMat);
  sBot.position.set(0, -H_MIC / 2 + 0.006, 0);
  doorGroup.add(fTop, fBot, fLeft, fRight, sTop, sBot);

  const winW = doorW - 0.088, winH = H_MIC - 0.092;
  const glassPane = new THREE.Mesh(
    new THREE.PlaneGeometry(winW, winH),
    phys('#0F1822', 0.06, { transparent: true, opacity: 0.30, clearcoat: 1, metalness: 0.15 })
  );
  glassPane.position.z = 0.011;
  const meshMat = new THREE.MeshStandardMaterial({
    map: faradayMeshTex(), transparent: true, opacity: 0.85, roughness: 0.4, metalness: 0.7, side: THREE.DoubleSide
  });
  const meshPane = new THREE.Mesh(new THREE.PlaneGeometry(winW, winH), meshMat);
  meshPane.position.z = 0.002;
  doorGroup.add(glassPane, meshPane);

  const handleCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(doorW / 2 - 0.024, 0.10, 0.012),
    new THREE.Vector3(doorW / 2 - 0.024, 0.085, 0.044),
    new THREE.Vector3(doorW / 2 - 0.024, -0.085, 0.044),
    new THREE.Vector3(doorW / 2 - 0.024, -0.10, 0.012),
  ]);
  const handle = shadowed(new THREE.Mesh(new THREE.TubeGeometry(handleCurve, 24, 0.0085, 12, false), steelMat));
  doorGroup.add(handle);

  const hookMat = std('#1E222B', 0.45);
  for (const hy of [0.075, -0.075]) {
    const hk = new THREE.Mesh(new THREE.BoxGeometry(0.009, 0.024, 0.028), hookMat);
    hk.position.set(doorW / 2 - 0.012, hy, -0.024);
    doorGroup.add(hk);
  }

  doorPivot.add(doorGroup);
  g.add(doorPivot);

  return {
    group: g, shell, doorPivot, turntablePivot, cavityLight, meshMat,
    cavityCenter: new THREE.Vector3(cavCenterX, thick + 0.022, 0.01),
    setDoorAngle(rad) { doorPivot.rotation.y = -rad; },
    setMeshVisible(op) { meshMat.opacity = op; meshPane.visible = op > 0.01; },
  };
}

// ── 3. MIDNIGHT MODERN KITCHEN SET (moody high-contrast lighting) ──────────
export function midnightKitchen(E) {
  const scene = new THREE.Scene();
  scene.environment = E.envMap;
  scene.environmentIntensity = 0.32;
  scene.background = new THREE.Color('#0A0E17');
  scene.fog = new THREE.Fog('#0A0E17', 5.0, 15);

  const floorTex = canvasTex(512, 512, (g, w, h) => {
    for (let i = 0; i < 8; i++) {
      const l = 34 + (i * 19) % 14;
      g.fillStyle = `rgb(${l + 12},${l + 4},${l - 4})`;
      g.fillRect(0, i * h / 8, w, h / 8);
      g.fillStyle = 'rgba(8,6,4,0.45)';
      g.fillRect(0, i * h / 8, w, 3);
    }
  }, [6, 6]);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(14, 14), std('#FFFFFF', 0.55, { map: floorTex }));
  floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);

  const backWall = shadowed(new THREE.Mesh(new THREE.BoxGeometry(10, 4, 0.2), std('#FFFFFF', 0.45, { map: subwayTileTex() })));
  backWall.position.set(0, 2, -2.02); scene.add(backWall);

  const cabMat = phys('#18202C', 0.48, { clearcoat: 0.15 });
  const counterBase = shadowed(new THREE.Mesh(new THREE.BoxGeometry(4.4, 0.88, 0.78), cabMat));
  counterBase.position.set(0, 0.44, -1.55); scene.add(counterBase);

  const brassMat = phys('#C49F4A', 0.28, { metalness: 0.88 });
  for (let i = 0; i < 6; i++) {
    const door = shadowed(new THREE.Mesh(new THREE.BoxGeometry(0.64, 0.72, 0.025), phys('#1E2736', 0.44)));
    door.position.set(-1.65 + i * 0.68, 0.45, -1.15); scene.add(door);
    const pull = new THREE.Mesh(new THREE.CylinderGeometry(0.007, 0.007, 0.14, 10), brassMat);
    pull.rotation.z = Math.PI / 2;
    pull.position.set(-1.65 + i * 0.68, 0.72, -1.12); scene.add(pull);
  }

  // Dark honed slate-marble quartz countertop (gives awesome contrast behind white ceramic bowl & stainless steel!)
  const quartzTex = canvasTex(512, 512, (g, w, h) => {
    g.fillStyle = '#38404E'; g.fillRect(0, 0, w, h);
    g.strokeStyle = 'rgba(180,195,215,0.16)'; g.lineWidth = 2.5;
    for (let i = 0; i < 18; i++) {
      g.beginPath(); g.moveTo((i * 73) % w, 0);
      g.bezierCurveTo((i * 111) % w, h * 0.35, (i * 59) % w, h * 0.7, (i * 137) % w, h);
      g.stroke();
    }
  }, [3, 1]);
  const counterTop = shadowed(new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.045, 0.84), phys('#4A5362', 0.22, { map: quartzTex, clearcoat: 0.7 })));
  counterTop.position.set(0, 0.90, -1.54); scene.add(counterTop);

  const upperCab = shadowed(new THREE.Mesh(new THREE.BoxGeometry(4.4, 0.85, 0.42), cabMat));
  upperCab.position.set(0, 2.02, -1.74); scene.add(upperCab);
  const ledStrip = new THREE.Mesh(
    new THREE.BoxGeometry(3.8, 0.015, 0.03),
    new THREE.MeshBasicMaterial({ color: '#FFE2AE' })
  );
  ledStrip.position.set(0, 1.59, -1.68); scene.add(ledStrip);

  const stoveTop = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.025, 0.56), phys('#0F1218', 0.25, { metalness: 0.75 }));
  stoveTop.position.set(-1.12, 0.935, -1.52); scene.add(stoveTop);
  const grateMat = std('#1E222A', 0.6, { metalness: 0.7 });
  for (const bx of [-1.28, -0.96]) for (const bz of [-1.64, -1.40]) {
    const burner = new THREE.Mesh(new THREE.TorusGeometry(0.068, 0.008, 8, 20), grateMat);
    burner.rotation.x = Math.PI / 2; burner.position.set(bx, 0.955, bz); scene.add(burner);
  }
  const pot = shadowed(new THREE.Mesh(new THREE.CylinderGeometry(0.10, 0.095, 0.12, 24), phys('#9BA5B4', 0.24, { metalness: 0.85 })));
  pot.position.set(-0.96, 1.02, -1.64); scene.add(pot);

  const mic = createHeroMicrowave();
  mic.group.position.set(0.16, 0.925, -1.52);
  scene.add(mic.group);

  const pasta = createPastaBowl();
  pasta.group.position.set(-0.34, 0.925, -1.36);
  scene.add(pasta.group);

  const forkMat = phys('#CBD4E0', 0.2, { metalness: 0.92 });
  const fork = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.004, 0.17), forkMat);
  fork.position.set(-0.52, 0.926, -1.34); fork.rotation.y = 0.18;
  scene.add(fork);

  const micPasta = createPastaBowl();
  micPasta.group.position.set(0, 0.005, 0);
  mic.turntablePivot.add(micPasta.group);

  // Balanced moody midnight lighting (zero overexposure!)
  const L = lightRig(scene, {
    key: '#FFD8A8', keyI: 2.0, keyPos: [1.4, 2.5, 0.9], target: [0.1, 1.05, -1.5],
    rimCol: '#6AA4FF', rimI: 1.5, sky: '#243554', ground: '#14110F', hemiI: 0.65, shadowBox: 2.2,
  });
  const counterFill = new THREE.PointLight('#FFCF94', 1.05, 3.0, 1.5);
  counterFill.position.set(0.1, 1.52, -1.25); scene.add(counterFill);
  const rimCool = new THREE.PointLight('#64B5FF', 1.15, 3.8, 1.5);
  rimCool.position.set(-1.3, 1.75, -0.7); scene.add(rimCool);

  return { scene, mic, pasta, micPasta, lights: L };
}

// ── 4. MACRO INSIDE-THE-FOOD H2O MOLECULAR WORLD (crystal-clear 3D molecules!) ──
export function macroWaterWorld(E) {
  const scene = new THREE.Scene();
  scene.environment = E.envMap;
  scene.environmentIntensity = 0.55;
  scene.background = new THREE.Color('#0E050A');
  scene.fog = new THREE.FogExp2('#14070D', 0.14);

  // Soft deep-burgundy organic background depth blobs
  const bgMat = phys('#44121B', 0.72, { emissive: '#1D0509', emissiveIntensity: 0.35 });
  for (let i = 0; i < 20; i++) {
    const a = (i / 20) * Math.PI * 2;
    const r = 2.6 + (i % 3) * 0.7;
    const blob = new THREE.Mesh(new THREE.SphereGeometry(0.55 + (i % 4) * 0.14, 16, 12), bgMat);
    blob.position.set(Math.cos(a) * r, Math.sin(a) * r * 1.3, -2.8 - (i % 5) * 1.3);
    scene.add(blob);
  }

  // 48 Large, ultra-crisp sculpted 3D H2O molecules (bent 104.5° geometry!)
  const oxMat = phys('#D92B3A', 0.22, { clearcoat: 0.9, emissive: '#C92818', emissiveIntensity: 0.15 });
  const hyMat = phys('#E6F0FF', 0.24, { clearcoat: 0.85, emissive: '#4CA8D8', emissiveIntensity: 0.12 });
  const bondMat = std('#B8C4D4', 0.35, { metalness: 0.3 });

  const oxGeo = new THREE.SphereGeometry(0.185, 24, 18);
  const hyGeo = new THREE.SphereGeometry(0.115, 18, 14);
  const bondGeo = new THREE.CylinderGeometry(0.034, 0.034, 0.20, 10);
  const angle = (104.5 * Math.PI) / 180 / 2;

  const molecules = [];
  for (let i = 0; i < 48; i++) {
    const mol = new THREE.Group();
    const ox = new THREE.Mesh(oxGeo, oxMat);
    mol.add(ox);
    for (const s of [-1, 1]) {
      const hx = Math.sin(angle) * 0.23 * s;
      const hy = Math.cos(angle) * 0.23;
      const hMesh = new THREE.Mesh(hyGeo, hyMat);
      hMesh.position.set(hx, hy, 0);
      const bond = new THREE.Mesh(bondGeo, bondMat);
      bond.position.set(hx * 0.5, hy * 0.5, 0);
      bond.rotation.z = -s * angle;
      mol.add(hMesh, bond);
    }
    const ring = 0.22 + (i % 5) * 0.26;
    const theta = i * 2.39996;
    const x = Math.cos(theta) * ring * 0.78;
    const y = Math.sin(theta) * ring * 1.15;
    const z = 1.1 - (i / 48) * 6.4;
    mol.position.set(x, y, z);
    mol.userData = { basePos: mol.position.clone(), seed: i * 1.37, baseRot: new THREE.Euler(i * 0.7, i * 1.1, i * 0.5) };
    scene.add(mol);
    molecules.push(mol);
  }

  // 3 Sleek 3D Cyan 2.45 GHz Sine-Wave Tubes sweeping cleanly THROUGH the H2O cloud (zero whiteout!)
  const waveMat = new THREE.MeshBasicMaterial({ color: '#42E2FF', transparent: true, opacity: 0.78 });
  const waveTubes = [];
  for (let i = 0; i < 3; i++) {
    const m = new THREE.Mesh(new THREE.BufferGeometry(), waveMat);
    scene.add(m);
    waveTubes.push(m);
  }

  // Crisp studio lighting on the molecules
  const key = new THREE.DirectionalLight('#FFE4D0', 2.6);
  key.position.set(1.5, 2.2, 2.5); scene.add(key);
  const cyanRim = new THREE.DirectionalLight('#4FD1E8', 1.8);
  cyanRim.position.set(-2.0, -1.0, -1.5); scene.add(cyanRim);
  scene.add(new THREE.HemisphereLight('#FFB49A', '#1B0712', 0.85));

  const COLD_OX = new THREE.Color('#2E78E8'), HOT_OX = new THREE.Color('#E82E1C');
  const COLD_EM = new THREE.Color('#1B56C0'), HOT_EM = new THREE.Color('#D42B12');

  return {
    scene,
    update(t, heat = 0.5, wavePower = 1.0) {
      oxMat.color.copy(COLD_OX).lerp(HOT_OX, heat);
      oxMat.emissive.copy(COLD_EM).lerp(HOT_EM, heat);
      oxMat.emissiveIntensity = 0.14 + heat * 0.42;
      hyMat.emissiveIntensity = 0.08 + heat * 0.18;

      // Update the 3 crisp cyan electromagnetic wave curves
      for (let w = 0; w < 3; w++) {
        const yOff = (w - 1) * 0.72;
        const pts = [];
        for (let s = 0; s <= 32; s++) {
          const u = s / 32;
          const z = 1.4 - u * 6.5;
          const x = Math.sin(z * 2.2 - t * 11 + w * 1.4) * 0.55;
          const y = yOff + Math.cos(z * 1.8 - t * 9 + w) * 0.18;
          pts.push(new THREE.Vector3(x, y, z));
        }
        const old = waveTubes[w].geometry;
        waveTubes[w].geometry = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 44, 0.018, 8, false);
        old.dispose();
      }

      // Violently twist H2O molecules in sync with passing waves!
      molecules.forEach((mol) => {
        const { basePos, seed, baseRot } = mol.userData;
        const phase = basePos.z * 2.4 - t * 11.0;
        const twist = Math.sin(phase) * (1.3 * wavePower);
        const jitter = heat * 0.045;
        mol.position.set(
          basePos.x + Math.sin(t * 17 + seed) * jitter,
          basePos.y + Math.cos(t * 19 + seed) * jitter,
          basePos.z + Math.sin(t * 15 + seed * 1.3) * jitter
        );
        mol.rotation.set(
          baseRot.x + twist * 1.15,
          baseRot.y + Math.cos(phase) * 0.9 * wavePower,
          baseRot.z + twist * 1.4
        );
      });
    },
  };
}

// ── 5. X-RAY MICROWAVE CUTAWAY STAGE (crisp high-contrast cyan glass) ──────
export function xrayMicrowaveStage(E) {
  const scene = new THREE.Scene();
  scene.background = canvasTex(64, 512, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, '#0B1C34'); gr.addColorStop(1, '#02060E');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
  });
  scene.add(new THREE.HemisphereLight('#9FD9FF', '#05080F', 0.65));
  const k = new THREE.DirectionalLight('#DDF4FF', 2.0); k.position.set(2, 3, 3); scene.add(k);
  const grid = new THREE.GridHelper(12, 32, '#1F6F88', '#0F2E3D');
  grid.position.y = -0.02; grid.material.transparent = true; grid.material.opacity = 0.4;
  scene.add(grid);

  const root = new THREE.Group();
  root.position.y = 0.02;
  scene.add(root);

  const xShellMat = xrayMaterial('#4FD1E8', 0.58);
  const xMetalBoxMat = xrayMaterial('#7AE8FF', 0.72);

  const W_M = 0.58, H_M = 0.34, D_M = 0.40;
  const outerShell = new THREE.Mesh(new THREE.BoxGeometry(W_M, H_M, D_M), xShellMat);
  outerShell.position.set(0, H_M / 2, 0);
  const edgeLines = new THREE.LineSegments(
    new THREE.EdgesGeometry(new THREE.BoxGeometry(W_M, H_M, D_M)),
    new THREE.LineBasicMaterial({ color: '#5BE0FF', transparent: true, opacity: 0.55 })
  );
  edgeLines.position.copy(outerShell.position);
  root.add(outerShell, edgeLines);

  const cavGroup = new THREE.Group();
  const cavW = 0.40, cavH = 0.28, cavD = 0.35;
  const cavX = -0.07;
  const cavBox = new THREE.Mesh(new THREE.BoxGeometry(cavW, cavH, cavD), xMetalBoxMat);
  cavBox.position.set(cavX, H_M / 2, 0);
  const cavEdges = new THREE.LineSegments(
    new THREE.EdgesGeometry(new THREE.BoxGeometry(cavW, cavH, cavD)),
    new THREE.LineBasicMaterial({ color: '#8AEFFF', transparent: true, opacity: 0.7 })
  );
  cavEdges.position.copy(cavBox.position);
  cavGroup.add(cavBox, cavEdges);
  root.add(cavGroup);

  // Internal Magnetron unit on right side
  const magGroup = new THREE.Group();
  magGroup.position.set(0.20, H_M * 0.52, -0.02);
  const magCore = new THREE.Mesh(
    new THREE.CylinderGeometry(0.036, 0.036, 0.09, 20),
    phys('#D97736', 0.3, { metalness: 0.85, emissive: '#E06018', emissiveIntensity: 0.28 })
  );
  const magFinMat = phys('#90B8D0', 0.3, { metalness: 0.85 });
  for (let i = -3; i <= 3; i++) {
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.088, 0.004, 0.088), magFinMat);
    fin.position.y = i * 0.011;
    magGroup.add(fin);
  }
  const duct = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.055, 0.075), xrayMaterial('#5BE4FF', 0.85));
  duct.position.set(-0.06, 0.03, 0);
  magGroup.add(magCore, duct);
  root.add(magGroup);

  const turntable = new THREE.Group();
  turntable.position.set(cavX, 0.055, 0);
  const trayMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.148, 0.142, 0.009, 40),
    phys('#8CE2FF', 0.12, { transparent: true, opacity: 0.52, emissive: '#2296B8', emissiveIntensity: 0.22 })
  );
  const motorBase = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.035, 0.03, 18), std('#4B6B82', 0.4, { metalness: 0.8 }));
  motorBase.position.y = -0.022;
  turntable.add(trayMesh, motorBase);
  const pasta = createPastaBowl();
  pasta.group.scale.setScalar(0.92);
  pasta.group.position.y = 0.005;
  turntable.add(pasta.group);
  root.add(turntable);

  // Crisp non-blown-out EM wave tubes
  const waveMat = new THREE.MeshBasicMaterial({ color: '#45E4FF', transparent: true, opacity: 0.85 });
  const leakMat = new THREE.MeshBasicMaterial({ color: '#FF4E4E', transparent: true, opacity: 0.88 });
  const waveMeshes = [];
  const N_WAVES = 4;
  for (let i = 0; i < N_WAVES; i++) {
    const mesh = new THREE.Mesh(new THREE.BufferGeometry(), waveMat);
    root.add(mesh);
    waveMeshes.push(mesh);
  }

  // Crisp Standing-Wave Hot Spots (translucent glowing crimson spheres) & Cold Dead Zones (blue rings)
  const hotGroup = new THREE.Group();
  const hotMat = new THREE.MeshBasicMaterial({ color: '#FF3820', transparent: true, opacity: 0.45, depthWrite: false });
  const coldMat = new THREE.MeshBasicMaterial({ color: '#38B2FF', transparent: true, opacity: 0.72, depthWrite: false });
  const hotSpheres = [];
  const coldRings = [];
  for (let i = 0; i < 4; i++) {
    const hs = new THREE.Mesh(new THREE.SphereGeometry(0.038, 18, 14), hotMat);
    hs.position.set(cavX - 0.12 + i * 0.085, 0.15 + (i % 2) * 0.02, (i % 2 === 0 ? -0.04 : 0.04));
    hotGroup.add(hs);
    hotSpheres.push(hs);
  }
  for (let i = 0; i < 3; i++) {
    const cr = new THREE.Mesh(new THREE.TorusGeometry(0.034, 0.0045, 8, 24), coldMat);
    cr.position.set(cavX - 0.075 + i * 0.085, 0.15, 0.02);
    hotGroup.add(cr);
    coldRings.push(cr);
  }
  root.add(hotGroup);

  function updateWaveTube(mesh, pts, radius = 0.0042) {
    const oldGeo = mesh.geometry;
    mesh.geometry = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 44, radius, 6, false);
    oldGeo.dispose();
  }

  return {
    scene, root, outerShell, cavGroup, turntable, pasta, hotGroup, magGroup,
    update(t, { mode = 'standing', spin = 0, showBox = true, showTurntable = true, showNodes = false, pastaHeat = 0, pastaSplit = 0 } = {}) {
      outerShell.visible = showBox;
      edgeLines.visible = showBox;
      cavGroup.visible = showBox;
      trayMesh.visible = showTurntable;
      motorBase.visible = showTurntable;
      turntable.rotation.y = spin;
      pasta.update(t, pastaHeat, pastaSplit);

      hotGroup.visible = showNodes;
      if (showNodes) {
        hotSpheres.forEach((s, i) => s.scale.setScalar(0.85 + 0.25 * Math.sin(t * 7 + i * 1.4)));
        coldRings.forEach((r, i) => { r.rotation.y = t * 1.5 + i; r.rotation.x = Math.sin(t * 2 + i) * 0.4; });
      }

      for (let i = 0; i < N_WAVES; i++) {
        const yOff = 0.11 + (i / (N_WAVES - 1)) * 0.14;
        const zOff = ((i % 2) * 2 - 1) * 0.055;
        const pts = [];
        if (mode === 'leak_all') {
          waveMeshes[i].material = i % 2 === 0 ? leakMat : waveMat;
          for (let s = 0; s <= 28; s++) {
            const u = s / 28;
            const x = 0.14 - u * 1.05;
            const amp = 0.022 * (0.4 + u * 1.05);
            const y = yOff + Math.sin(u * 22 - t * 14 + i) * amp;
            const z = zOff * (1 + u * 1.6) + Math.cos(u * 14 - t * 10 + i) * amp * 0.4;
            pts.push(new THREE.Vector3(x, y, z));
          }
        } else if (mode === 'window_leak') {
          waveMeshes[i].material = leakMat;
          for (let s = 0; s <= 28; s++) {
            const u = s / 28;
            const x = 0.13 - Math.sin(u * Math.PI * 0.7) * 0.24 + (i - 1.5) * 0.05;
            const z = -0.06 + u * 0.85;
            const y = yOff + Math.sin(u * 24 - t * 15 + i) * 0.02;
            pts.push(new THREE.Vector3(x, y, z));
          }
        } else {
          waveMeshes[i].material = waveMat;
          const standingEnv = Math.cos(t * 10 + i * 0.6);
          for (let s = 0; s <= 28; s++) {
            const u = s / 28;
            const x = 0.13 - u * 0.39;
            const y = yOff + Math.sin(u * Math.PI * 4) * 0.03 * standingEnv;
            const z = zOff + Math.sin(u * Math.PI * 3) * 0.012 * Math.sin(t * 9 + i);
            pts.push(new THREE.Vector3(x, y, z));
          }
        }
        updateWaveTube(waveMeshes[i], pts, mode === 'leak_all' ? 0.0052 : 0.0042);
      }
    },
  };
}

// ── 6. MACRO FARADAY MESH DOOR CROSS-SECTION ───────────────────────────────
export function faradayMeshStage(E) {
  const scene = new THREE.Scene();
  scene.environment = E.envMap;
  scene.environmentIntensity = 0.5;
  scene.background = new THREE.Color('#050D1A');
  scene.fog = new THREE.Fog('#050D1A', 4.5, 11);
  scene.add(new THREE.HemisphereLight('#A8D8FF', '#08101C', 0.8));
  const key = new THREE.DirectionalLight('#E0F4FF', 2.4); key.position.set(2, 3, 3); scene.add(key);

  const plateGroup = new THREE.Group();
  const metalMat = phys('#2A3342', 0.26, { metalness: 0.88, clearcoat: 0.3 });
  const rimMat = phys('#64748B', 0.22, { metalness: 0.92 });

  const rows = 9, cols = 7, pitch = 0.16;
  const cellRingGeo = new THREE.TorusGeometry(0.056, 0.025, 12, 24);
  const inst = new THREE.InstancedMesh(cellRingGeo, metalMat, rows * cols);
  const dummy = new THREE.Object3D();
  let idx = 0;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const y = (r - (rows - 1) / 2) * pitch;
      const z = (c - (cols - 1) / 2) * pitch + (r % 2) * (pitch * 0.5);
      dummy.position.set(0, y, z);
      dummy.rotation.set(0, Math.PI / 2, 0);
      dummy.updateMatrix();
      inst.setMatrixAt(idx++, dummy.matrix);
    }
  }
  plateGroup.add(inst);

  const glassPane = new THREE.Mesh(
    new THREE.BoxGeometry(0.022, 1.85, 1.6),
    phys('#8AD8FF', 0.06, { transparent: true, opacity: 0.20, clearcoat: 1 })
  );
  glassPane.position.set(0.065, 0, 0);
  plateGroup.add(glassPane);
  for (const sy of [-0.94, 0.94]) {
    const rail = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.06, 1.65), rimMat);
    rail.position.set(0.02, sy, 0);
    plateGroup.add(rail);
  }
  scene.add(plateGroup);

  const cyanWaveMat = new THREE.MeshBasicMaterial({ color: '#42E8FF', transparent: true, opacity: 0.9 });
  const bounceWaves = [];
  for (let i = 0; i < 4; i++) {
    const m = new THREE.Mesh(new THREE.BufferGeometry(), cyanWaveMat);
    scene.add(m);
    bounceWaves.push(m);
  }
  const flashMat = new THREE.MeshBasicMaterial({ color: '#64ECFF', transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false });
  const flashDisc = new THREE.Mesh(new THREE.SphereGeometry(0.14, 18, 14), flashMat);
  flashDisc.scale.set(0.22, 1.2, 1.2);
  flashDisc.position.set(-0.04, 0, 0);
  scene.add(flashDisc);

  const lightRayMat = new THREE.MeshBasicMaterial({ color: '#FFE066', transparent: true, opacity: 0.85 });
  const lightRays = [];
  for (let i = 0; i < 6; i++) {
    const r = new THREE.Mesh(new THREE.CylinderGeometry(0.0055, 0.0055, 2.3, 8), lightRayMat);
    r.rotation.z = Math.PI / 2;
    const row = (i % 3) - 1, col = Math.floor(i / 3) * 2 - 1;
    r.position.set(0.15, row * pitch, col * pitch + (Math.abs(row) % 2) * (pitch * 0.5));
    scene.add(r);
    lightRays.push(r);
  }
  const photonGeo = new THREE.SphereGeometry(0.017, 12, 10);
  const photonMat = new THREE.MeshBasicMaterial({ color: '#FFF2A0' });
  const photons = [];
  for (let i = 0; i < 6; i++) {
    const p = new THREE.Mesh(photonGeo, photonMat);
    scene.add(p);
    photons.push(p);
  }

  return {
    scene,
    update(t, meshActive = 1.0) {
      plateGroup.position.y = (1 - meshActive) * -1.4;
      flashMat.opacity = meshActive * (0.2 + 0.22 * Math.abs(Math.sin(t * 9)));

      for (let i = 0; i < 4; i++) {
        const y0 = (i - 1.5) * 0.26;
        const z0 = (i % 2 === 0 ? -0.14 : 0.14);
        const pts = [];
        for (let s = 0; s <= 32; s++) {
          const u = s / 32;
          const isBounce = i >= 2;
          const x = -1.65 + u * 1.60;
          const dir = isBounce ? 1 : -1;
          const y = y0 + Math.sin(u * 10 + dir * t * 11 + i) * 0.135;
          pts.push(new THREE.Vector3(x, y, z0));
        }
        const old = bounceWaves[i].geometry;
        bounceWaves[i].geometry = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 44, 0.014, 8, false);
        old.dispose();
      }

      photons.forEach((p, i) => {
        const ray = lightRays[i];
        const px = -1.0 + ((t * 1.45 + i * 0.37) % 2.3);
        p.position.set(px, ray.position.y, ray.position.z);
      });
    },
  };
}

// ── 7. MECHANICAL DOOR LATCH & TRIPLE INTERLOCK SWITCHES + FUSE ────────────
export function interlockSwitchStage(E) {
  const scene = new THREE.Scene();
  scene.environment = E.envMap;
  scene.environmentIntensity = 0.45;
  scene.background = new THREE.Color('#071120');
  scene.add(new THREE.HemisphereLight('#A8D8FF', '#050A14', 0.8));
  const key = new THREE.DirectionalLight('#E2F2FF', 2.4); key.position.set(1.5, 2.5, 3); scene.add(key);

  const bracket = new THREE.Mesh(new THREE.BoxGeometry(0.14, 1.35, 0.45), xrayMaterial('#4FD1E8', 0.65));
  bracket.position.set(0.18, 0, 0);
  scene.add(bracket);

  const doorLatchGroup = new THREE.Group();
  const doorEdge = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.4, 0.38), phys('#1E2634', 0.3, { metalness: 0.7 }));
  doorEdge.position.set(-0.42, 0, 0);
  const hookMat = phys('#2D3748', 0.35, { metalness: 0.75 });
  const topHook = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.065, 0.06), hookMat);
  topHook.position.set(-0.22, 0.30, 0);
  const topTip = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.11, 0.06), hookMat);
  topTip.position.set(-0.08, 0.25, 0);
  const botHook = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.065, 0.06), hookMat);
  botHook.position.set(-0.22, -0.28, 0);
  const botTip = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.11, 0.06), hookMat);
  botTip.position.set(-0.08, -0.33, 0);
  doorLatchGroup.add(doorEdge, topHook, topTip, botHook, botTip);
  scene.add(doorLatchGroup);

  function makeMicroSwitch(y, accentCol) {
    const sw = new THREE.Group();
    sw.position.set(0.15, y, 0);
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.13, 0.09), phys('#181D26', 0.45));
    const plunger = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.075, 14), phys(accentCol, 0.3, { emissive: accentCol, emissiveIntensity: 0.35 }));
    plunger.rotation.z = Math.PI / 2;
    plunger.position.set(-0.13, 0, 0);
    const termMat = phys('#CBD5E1', 0.2, { metalness: 0.95 });
    for (const ty of [-0.032, 0.032]) {
      const t = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.014, 0.04), termMat);
      t.position.set(0.14, ty, 0);
      sw.add(t);
    }
    sw.add(body, plunger);
    return { group: sw, plunger };
  }

  const swPrimary = makeMicroSwitch(0.28, '#FF4757');
  const swMonitor = makeMicroSwitch(0.0, '#FFB830');
  const swSecondary = makeMicroSwitch(-0.30, '#38D996');
  scene.add(swPrimary.group, swMonitor.group, swSecondary.group);

  const wireMatMain = phys('#38D9FF', 0.3, { emissive: '#22C8FF', emissiveIntensity: 0.85 });
  const wireMatFail = phys('#FFB020', 0.3, { emissive: '#FF8800', emissiveIntensity: 0.2 });
  const mainWireCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0.29, 0.28, 0), new THREE.Vector3(0.46, 0.28, 0.05),
    new THREE.Vector3(0.46, -0.30, 0.05), new THREE.Vector3(0.29, -0.30, 0),
  ]);
  const mainWire = new THREE.Mesh(new THREE.TubeGeometry(mainWireCurve, 32, 0.013, 8, false), wireMatMain);
  const fuseWireCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0.29, 0.0, 0), new THREE.Vector3(0.44, 0.0, -0.05),
    new THREE.Vector3(0.56, -0.02, 0),
  ]);
  const fuseWire = new THREE.Mesh(new THREE.TubeGeometry(fuseWireCurve, 20, 0.012, 8, false), wireMatFail);
  scene.add(mainWire, fuseWire);

  const fuseGroup = new THREE.Group();
  fuseGroup.position.set(0.56, 0.0, 0);
  const capMat = phys('#D4DCE8', 0.2, { metalness: 0.95 });
  const capTop = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.048, 0.07, 20), capMat);
  capTop.position.y = 0.14;
  const capBot = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.048, 0.07, 20), capMat);
  capBot.position.y = -0.14;
  const glassTube = new THREE.Mesh(
    new THREE.CylinderGeometry(0.044, 0.044, 0.24, 24),
    phys('#D8F3FF', 0.05, { transparent: true, opacity: 0.35, clearcoat: 1 })
  );
  const filMat = new THREE.MeshBasicMaterial({ color: '#FFCC66' });
  const filTop = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.12, 8), filMat);
  filTop.position.y = 0.06;
  const filBot = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.12, 8), filMat);
  filBot.position.y = -0.06;
  const fuseFlashMat = new THREE.MeshBasicMaterial({ color: '#FFE896', transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false });
  const fuseFlash = new THREE.Mesh(new THREE.SphereGeometry(0.11, 18, 14), fuseFlashMat);
  fuseGroup.add(capTop, capBot, glassTube, filTop, filBot, fuseFlash);
  scene.add(fuseGroup);

  return {
    scene,
    update(t, doorOpen = 0, fuseBlown = 0) {
      doorLatchGroup.position.x = -doorOpen * 0.26;
      const push = (1 - doorOpen) * 0.032;
      swPrimary.plunger.position.x = -0.13 + push;
      swSecondary.plunger.position.x = -0.13 + push;
      swMonitor.plunger.position.x = -0.13 + doorOpen * 0.025;

      const powerOn = doorOpen < 0.18 && fuseBlown < 0.3;
      wireMatMain.emissiveIntensity = powerOn ? 0.95 : 0.04;
      wireMatMain.color.set(powerOn ? '#38D9FF' : '#253342');

      wireMatFail.emissiveIntensity = fuseBlown > 0.15 && fuseBlown < 0.75 ? 1.3 : 0.12;
      const flash = fuseBlown > 0.25 && fuseBlown < 0.75 ? Math.sin(((fuseBlown - 0.25) / 0.5) * Math.PI) : 0;
      fuseFlashMat.opacity = flash * 0.85;
      fuseFlash.scale.setScalar(0.6 + flash * 1.1);

      if (fuseBlown > 0.55) {
        filTop.position.y = 0.085; filTop.rotation.z = 0.25;
        filBot.position.y = -0.085; filBot.rotation.z = -0.25;
        filMat.color.set('#4A5568');
      } else {
        filTop.position.y = 0.06; filTop.rotation.z = 0;
        filBot.position.y = -0.06; filBot.rotation.z = 0;
        filMat.color.set(flash > 0.1 ? '#FFFFFF' : '#FFCC66');
      }
    },
  };
}

// ── 8. CAVITY MAGNETRON OVERHEAT + COOLING FINS & AXIAL FAN (razor-sharp metallic!) ──
export function magnetronCoolingStage(E) {
  const scene = new THREE.Scene();
  scene.environment = E.envMap;
  scene.environmentIntensity = 0.55;
  scene.background = new THREE.Color('#060C18');
  scene.add(new THREE.HemisphereLight('#9FD9FF', '#120808', 0.75));
  const key = new THREE.DirectionalLight('#E8F5FF', 2.4); key.position.set(2, 3, 3); scene.add(key);

  const root = new THREE.Group();
  scene.add(root);

  // Detailed ribbed copper anode block (glows rich cherry-orange, never washed white!)
  const copperMat = phys('#C86A2E', 0.30, { metalness: 0.86, emissive: '#D62408', emissiveIntensity: 0 });
  const core = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.36, 32), copperMat);
  root.add(core);
  // Radial copper resonant ribs around core
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    const rib = new THREE.Mesh(new THREE.BoxGeometry(0.018, 0.34, 0.025), copperMat);
    rib.position.set(Math.cos(a) * 0.112, 0, Math.sin(a) * 0.112);
    rib.rotation.y = -a;
    root.add(rib);
  }

  const magnetMat = phys('#1F242D', 0.45, { metalness: 0.45 });
  for (const sy of [0.21, -0.21]) {
    const mg = new THREE.Mesh(new THREE.CylinderGeometry(0.175, 0.175, 0.065, 32), magnetMat);
    mg.position.y = sy;
    root.add(mg);
  }
  const ceramicMat = phys('#DFDBD0', 0.25, { clearcoat: 0.7 });
  const topCer = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.07, 24), ceramicMat);
  topCer.position.y = 0.28;
  const dome = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.052, 0.075, 24), phys('#D9B44A', 0.22, { metalness: 0.92 }));
  dome.position.y = 0.34;
  const hvBox = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.14, 0.18), phys('#6E7A8D', 0.35, { metalness: 0.85 }));
  hvBox.position.y = -0.31;
  root.add(topCer, dome, hvBox);

  // 12 Stacked Brushed-Aluminum Cooling Fins
  const finsGroup = new THREE.Group();
  const finMat = phys('#B8C6D6', 0.24, { metalness: 0.9, clearcoat: 0.25 });
  for (let i = 0; i < 12; i++) {
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.008, 0.36), finMat);
    fin.position.y = -0.155 + i * 0.028;
    finsGroup.add(fin);
  }
  const yokeMat = phys('#7C899A', 0.32, { metalness: 0.88 });
  for (const sx of [-0.215, 0.215]) {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.38, 0.36), yokeMat);
    wall.position.x = sx;
    finsGroup.add(wall);
  }
  root.add(finsGroup);

  // Rear 7-Blade Curved Axial Cooling Fan
  const fanAssembly = new THREE.Group();
  fanAssembly.position.set(0, 0, -0.44);
  const shroud = new THREE.Mesh(new THREE.TorusGeometry(0.25, 0.022, 12, 36), phys('#1B222E', 0.4, { metalness: 0.5 }));
  fanAssembly.add(shroud);
  const fanRotor = new THREE.Group();
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.05, 20), phys('#2D3748', 0.35, { metalness: 0.6 }));
  hub.rotation.x = Math.PI / 2;
  fanRotor.add(hub);
  const bladeMat = phys('#3B4B61', 0.28, { metalness: 0.55, clearcoat: 0.5 });
  for (let i = 0; i < 7; i++) {
    const bPivot = new THREE.Group();
    bPivot.rotation.z = (i / 7) * Math.PI * 2;
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.17, 0.012), bladeMat);
    blade.position.set(0.01, 0.13, 0);
    blade.rotation.y = 0.45;
    bPivot.add(blade);
    fanRotor.add(bPivot);
  }
  fanAssembly.add(fanRotor);
  root.add(fanAssembly);

  // 18 Cool-Air Streamlines
  const airMat = new THREE.MeshBasicMaterial({ color: '#6CE8FF', transparent: true, opacity: 0, depthWrite: false });
  const airStreams = [];
  for (let i = 0; i < 18; i++) {
    const st = new THREE.Mesh(new THREE.CylinderGeometry(0.0045, 0.0045, 0.24, 6), airMat);
    st.rotation.x = Math.PI / 2;
    const ang = (i / 18) * Math.PI * 2;
    const rad = 0.06 + (i % 3) * 0.065;
    st.userData = { x: Math.cos(ang) * rad, y: Math.sin(ang) * rad, off: (i * 0.19) % 1 };
    root.add(st);
    airStreams.push(st);
  }

  const heatLight = new THREE.PointLight('#FF3B1A', 0, 2.2, 1.6);
  heatLight.position.set(0, 0, 0.32);
  root.add(heatLight);

  return {
    scene, root,
    update(t, heat = 1, finsIn = 0, fanIn = 0) {
      const pulse = 0.88 + 0.12 * Math.sin(t * 10);
      copperMat.emissiveIntensity = heat * 0.72 * pulse;
      heatLight.intensity = heat * 1.45 * pulse;

      finsGroup.visible = finsIn > 0.01;
      finsGroup.scale.setScalar(0.75 + 0.25 * finsIn);
      finsGroup.position.x = (1 - finsIn) * 0.85;

      fanAssembly.visible = fanIn > 0.01;
      fanAssembly.position.z = -0.44 - (1 - fanIn) * 0.7;
      fanRotor.rotation.z = -t * 18 * fanIn;

      airMat.opacity = fanIn * 0.58;
      airStreams.forEach((s) => {
        const u = (t * 2.2 + s.userData.off) % 1;
        s.position.set(s.userData.x, s.userData.y, -0.42 + u * 0.92);
      });
    },
  };
}
