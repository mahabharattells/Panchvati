// HOW YOU ACCIDENTALLY REINVENTED THE MODERN MICROWAVE OVEN — Polished High-Detail Deep Dive 3D Shot List
import * as THREE from 'three';
import { clamp, lerp, seg, eo, eio, eob } from './core/lib.js';
import { L, Wd } from './core/timing.js';
import { camera } from './core/engine.js';
import { label, pill, warning } from './core/look2d.js';
import {
  midnightKitchen,
  macroWaterWorld,
  xrayMicrowaveStage,
  faradayMeshStage,
  interlockSwitchStage,
  magnetronCoolingStage,
} from './models.js';

const V3 = (x, y, z) => new THREE.Vector3(x, y, z);
const lerpV = (a, b, k) => a.clone().lerp(b, k);
function screen(p, cam) {
  const v = p.clone().project(cam);
  return [(v.x + 1) / 2 * 1080, (1 - v.y) / 2 * 1920];
}

export function buildShots(E) {
  const S = [], CUES = [];
  const add = (o) => (S.push(o), o);
  const cue = (t, type, o = {}) => CUES.push({ t: +t.toFixed(3), type, ...o });
  const cut = (i) => (i === 0 ? 0 : L(i) - 0.08);
  const cam = camera(32);

  // Tuned film looks: high bloomThreshold so speculars stay crisp and zero frames wash out!
  const KLOOK = { aperture: 0.0020, maxblur: 0.007, bloom: 0.16, bloomThreshold: 0.90, vignette: 0.36, warm: 0.02 };
  const XLOOK = { aperture: 0.0012, maxblur: 0.005, bloom: 0.30, bloomThreshold: 0.72, vignette: 0.42, warm: -0.02 };
  const MLOOK = { aperture: 0.0032, maxblur: 0.009, bloom: 0.28, bloomThreshold: 0.78, vignette: 0.42, warm: 0.02 };

  const K = midnightKitchen(E);
  const MW = macroWaterWorld(E);
  const X = xrayMicrowaveStage(E);
  const F = faradayMeshStage(E);
  const SW = interlockSwitchStage(E);
  const MAG = magnetronCoolingStage(E);

  const resetKitchen = () => {
    K.mic.group.visible = true;
    K.mic.setDoorAngle(0);
    K.mic.setMeshVisible(0.85);
    K.mic.turntablePivot.rotation.y = 0;
    K.mic.cavityLight.intensity = 0.42;
    K.pasta.group.visible = true;
    K.pasta.update(0, 0, 0);
    K.micPasta.update(0, 0, 0);
  };

  // ── S01 · HOOK (0.00s, Lines 0-1): Midnight kitchen, cold stove -> leftover pasta bowl ──
  {
    const st = cut(0);
    add({
      id: 'S01', at: st, note: 'Midnight kitchen: smooth arc from cold stove to leftover pasta bowl',
      draw(lt, d, t, blit) {
        resetKitchen();
        K.mic.group.visible = false;
        K.pasta.update(t, 0, 0);
        const k = eio(clamp(lt / d));
        const p0 = V3(-0.98, 1.38, -0.42), p1 = V3(-0.22, 1.24, -0.78);
        const l0 = V3(-0.82, 1.02, -1.52), l1 = V3(-0.34, 0.99, -1.36);
        cam.position.copy(lerpV(p0, p1, k));
        cam.position.y += Math.sin(k * Math.PI) * 0.05;
        const target = lerpV(l0, l1, k);
        cam.lookAt(target);
        E.render(K.scene, cam, { ...KLOOK, focus: cam.position.distanceTo(target), t });
        blit();
        pill('12:04 AM', 540, 310, eob(seg(lt, 0.15, 0.45)), '#9FD9FF', 'rgba(10,16,28,0.84)', 54);
      },
    });
    cue(st + 0.1, 'slide', { dur: 1.2, gain: 0.45 });
  }

  // ── S02 · MAGNETRON FIRES WAVES (Line 2) ──
  {
    const st = cut(2);
    add({
      id: 'S02', at: st, note: 'X-ray magnetron blasting 2.45 GHz radio waves straight into food',
      draw(lt, d, t, blit) {
        const k = eio(clamp(lt / d));
        X.update(t, { mode: 'leak_all', showBox: false, showTurntable: false, showNodes: false, pastaHeat: k * 0.4 });
        const ang = lerp(0.55, 0.12, k);
        const rad = lerp(0.95, 0.72, k);
        cam.position.set(0.02 + Math.sin(ang) * rad, lerp(0.38, 0.28, k), Math.cos(ang) * rad);
        const target = V3(0.02, 0.18, 0);
        cam.lookAt(target);
        E.render(X.scene, cam, { ...XLOOK, focus: cam.position.distanceTo(target), t });
        blit();
        const [lx, ly] = screen(V3(0.20, 0.22, 0), cam);
        label('MAGNETRON', 770, 440, lx, ly, eob(seg(lt, 0.25, 0.55)));
      },
    });
    cue(st, 'whoosh');
    cue(st + 0.2, 'zip', { gain: 0.65 });
  }

  // ── S03 · MACRO INSIDE THE FOOD (Lines 3-4): Crisp 3D H2O molecules twisting! ──
  {
    const st = cut(3);
    add({
      id: 'S03', at: st, note: 'Macro inside food: 3D H2O molecules twisting rapidly and heating red',
      draw(lt, d, t, blit) {
        const k = eio(clamp(lt / d));
        MW.update(t, k, 1.0);
        cam.position.set(Math.sin(lt * 0.75) * 0.20, Math.cos(lt * 0.55) * 0.10, lerp(2.15, 0.35, k));
        cam.lookAt(Math.sin(lt * 0.45) * 0.06, 0, cam.position.z - 2.4);
        E.render(MW.scene, cam, { ...MLOOK, focus: 2.0, t });
        blit();
        pill('2.45 BILLION / SEC', 540, 310, eob(seg(lt, 0.35, 0.65)), '#FFD43B', 'rgba(14,10,16,0.86)', 50);
      },
    });
    cue(st, 'whoosh');
    cue(st + 0.15, 'sizzle', { dur: 3.8, gain: 0.7 });
  }

  // ── S04 · TERRIFYING CATCH (Lines 5-8): Waves blasting across kitchen! ──
  {
    const st = cut(5);
    add({
      id: 'S04', at: st, note: 'X-ray pull-back: uncontained waves blast straight across the room',
      draw(lt, d, t, blit) {
        const k = eio(clamp(lt / d));
        X.update(t, { mode: 'leak_all', showBox: false, showTurntable: false, showNodes: false, pastaHeat: 0.45 });
        const p0 = V3(0.05, 0.24, 0.68), p1 = V3(-0.35, 0.46, 1.38);
        const l0 = V3(-0.05, 0.18, 0), l1 = V3(-0.28, 0.18, 0);
        cam.position.copy(lerpV(p0, p1, k));
        const target = lerpV(l0, l1, k);
        cam.lookAt(target);
        E.render(X.scene, cam, { ...XLOOK, focus: cam.position.distanceTo(target), t });
        blit();
        const warnAt = L(6) - st;
        if (lt > warnAt) {
          warning(540, 410, eob(seg(lt, warnAt, warnAt + 0.35)) * 0.85);
          pill('UNCONTAINED WAVES', 540, 1210, eob(seg(lt, warnAt + 0.2, warnAt + 0.5)), '#FF5A5A', 'rgba(12,14,20,0.88)', 54);
        }
      },
    });
    cue(st, 'whoosh');
    cue(L(6) - 0.05, 'alarm', { dur: 2.2, gain: 0.55 });
  }

  // ── S05 · FIX #1 (Line 9): Sealed metal box traps waves ──
  {
    const st = cut(9);
    add({
      id: 'S05', at: st, note: 'X-ray sealed metal box snaps into place, bouncing waves back in',
      draw(lt, d, t, blit) {
        const k = eio(clamp(lt / d));
        const boxPop = eob(seg(lt, 0.12, 0.65));
        X.update(t, { mode: 'standing', showBox: true, showTurntable: false, showNodes: false, pastaHeat: 0.35 });
        X.cavGroup.scale.setScalar(0.7 + 0.3 * boxPop);
        const ang = lerp(-0.45, 0.32, k);
        cam.position.set(Math.sin(ang) * 1.02, lerp(0.36, 0.29, k), Math.cos(ang) * 1.02);
        const target = V3(-0.04, 0.18, 0);
        cam.lookAt(target);
        E.render(X.scene, cam, { ...XLOOK, focus: cam.position.distanceTo(target), t });
        blit();
        const [lx, ly] = screen(V3(-0.24, 0.30, 0.15), cam);
        label('SEALED METAL BOX', 540, 390, lx, ly, eob(seg(lt, 0.35, 0.7)));
      },
    });
    cue(st, 'whoosh');
    cue(st + 0.25, 'slam', { gain: 0.6 });
  }

  // ── S06 · PROBLEM #2 (Lines 10-13): Crisp Lava Hot vs. Frozen pasta bowl ──
  {
    const st = cut(10);
    add({
      id: 'S06', at: st, note: 'Macro pasta bowl: left side steaming lava-hot, right side frosted frozen',
      draw(lt, d, t, blit) {
        resetKitchen();
        K.mic.group.visible = false;
        const splitK = eo(seg(lt, 0.9, 2.2));
        K.pasta.update(t, 0, splitK);
        const k = eio(clamp(lt / d));
        const ang = lerp(-0.32, 0.32, k);
        const rad = lerp(0.56, 0.44, k);
        const center = V3(-0.34, 0.99, -1.36);
        cam.position.set(center.x + Math.sin(ang) * rad, lerp(1.26, 1.18, k), center.z + Math.cos(ang) * rad);
        cam.lookAt(center);
        E.render(K.scene, cam, { ...KLOOK, focus: cam.position.distanceTo(center), t });
        blit();
        const hotAt = L(12) - st, coldAt = L(13) - st;
        if (lt > hotAt) {
          const [hx, hy] = screen(V3(-0.41, 1.02, -1.36), cam);
          label('LAVA HOT', 290, 560, hx, hy, eob(seg(lt, hotAt, hotAt + 0.3)));
        }
        if (lt > coldAt) {
          const [cx, cy] = screen(V3(-0.27, 1.02, -1.36), cam);
          label('FROZEN', 810, 560, cx, cy, eob(seg(lt, coldAt, coldAt + 0.3)));
        }
      },
    });
    cue(st, 'whoosh');
    cue(L(12), 'sizzle', { dur: 1.0, gain: 0.55 });
    cue(L(13), 'pop', { gain: 0.65 });
  }

  // ── S07 · STANDING WAVES (Lines 14-15) ──
  {
    const st = cut(14);
    add({
      id: 'S07', at: st, note: 'X-ray cavity: standing waves creating fixed red hot spots & blue dead zones',
      draw(lt, d, t, blit) {
        const k = eio(clamp(lt / d));
        X.cavGroup.scale.setScalar(1);
        X.update(t, { mode: 'standing', showBox: true, showTurntable: false, showNodes: true, pastaSplit: 1.0 });
        const ang = lerp(0.45, -0.35, k);
        cam.position.set(-0.05 + Math.sin(ang) * 0.88, lerp(0.42, 0.28, k), Math.cos(ang) * 0.88);
        const target = V3(-0.06, 0.17, 0);
        cam.lookAt(target);
        E.render(X.scene, cam, { ...XLOOK, focus: cam.position.distanceTo(target), t });
        blit();
        const [hx, hy] = screen(V3(-0.19, 0.16, -0.04), cam);
        const [cx, cy] = screen(V3(0.01, 0.15, 0.02), cam);
        label('HOT SPOT', 300, 440, hx, hy, eob(seg(lt, 0.9, 1.25)));
        label('DEAD ZONE', 780, 1180, cx, cy, eob(seg(lt, 1.7, 2.05)));
      },
    });
    cue(st, 'whoosh');
    cue(st + 0.9, 'pop', { gain: 0.55 });
  }

  // ── S08 · FIX #2 (Line 16): Spinning glass turntable ──
  {
    const st = cut(16);
    add({
      id: 'S08', at: st, note: 'X-ray spinning glass turntable rotating pasta evenly through hot nodes',
      draw(lt, d, t, blit) {
        const k = eio(clamp(lt / d));
        X.update(t, {
          mode: 'standing', showBox: true, showTurntable: true, showNodes: true,
          spin: lt * 2.1, pastaHeat: 0.35 + k * 0.65, pastaSplit: Math.max(0, 1 - k * 1.4),
        });
        const ang = lerp(-0.32, 0.36, k);
        const rad = lerp(0.84, 0.68, k);
        cam.position.set(-0.06 + Math.sin(ang) * rad, lerp(0.36, 0.24, k), Math.cos(ang) * rad);
        const target = V3(-0.07, 0.14, 0);
        cam.lookAt(target);
        E.render(X.scene, cam, { ...XLOOK, focus: cam.position.distanceTo(target), t });
        blit();
        const [tx, ty] = screen(V3(-0.07, 0.06, 0.13), cam);
        label('SPINNING TURNTABLE', 540, 1210, tx, ty, eob(seg(lt, 0.35, 0.7)));
      },
    });
    cue(st, 'whoosh');
    cue(st + 0.2, 'sparkle', { dur: 1.4, gain: 0.55 });
  }

  // ── S09 · PROBLEM #3 (Lines 17-19): Window leak! ──
  {
    const st = cut(17);
    add({
      id: 'S09', at: st, note: 'X-ray side-front angle: waves leaking straight out of unshielded glass window',
      draw(lt, d, t, blit) {
        const k = eio(clamp(lt / d));
        const leakOn = lt > (L(19) - st - 0.1);
        X.update(t, {
          mode: leakOn ? 'window_leak' : 'standing',
          showBox: true, showTurntable: true, showNodes: false, spin: t * 1.5, pastaHeat: 0.75,
        });
        const p0 = V3(0.58, 0.28, 0.68), p1 = V3(0.76, 0.34, 0.98);
        const target = V3(-0.05, 0.18, leakOn ? 0.25 : 0.02);
        cam.position.copy(lerpV(p0, p1, k));
        cam.lookAt(target);
        E.render(X.scene, cam, { ...XLOOK, focus: cam.position.distanceTo(target), t });
        blit();
        if (leakOn) {
          pill('WINDOW LEAK!', 540, 340, eob(seg(lt, L(19) - st, L(19) - st + 0.35)), '#FF5A5A');
        }
      },
    });
    cue(st, 'whoosh');
    cue(L(19), 'alarm', { dur: 1.6, gain: 0.55 });
  }

  // ── S10 · FIX #3 (Lines 20-22): Macro Faraday Mesh Door ──
  {
    const st = cut(20);
    add({
      id: 'S10', at: st, note: 'Macro 3D Faraday mesh: 12cm cyan waves bounce back while golden light passes through 1mm holes',
      draw(lt, d, t, blit) {
        const k = eio(clamp(lt / d));
        const meshDrop = eob(seg(lt, 0.08, 0.65));
        F.update(t, meshDrop);
        const p0 = V3(-0.35, 0.32, 1.95), p1 = V3(0.58, 0.12, 1.52);
        const target = V3(-0.08, 0.0, 0);
        cam.position.copy(lerpV(p0, p1, k));
        cam.lookAt(target);
        E.render(F.scene, cam, { ...XLOOK, bloom: 0.35, focus: cam.position.distanceTo(target), t });
        blit();
        const [mx, my] = screen(V3(0.0, 0.16, 0.05), cam);
        label('1 mm MESH HOLES', 540, 320, mx, my, eob(seg(lt, 0.4, 0.8)));
        const waveAt = L(21) - st, lightAt = L(22) - st;
        if (lt > waveAt) {
          const [wx, wy] = screen(V3(-0.52, -0.1, 0), cam);
          label('12 cm WAVES', 280, 1210, wx, wy, eob(seg(lt, waveAt, waveAt + 0.35)));
        }
        if (lt > lightAt) {
          const [lx, ly] = screen(V3(0.42, 0.0, 0), cam);
          label('VISIBLE LIGHT ✓', 780, 1210, lx, ly, eob(seg(lt, lightAt, lightAt + 0.35)));
        }
      },
    });
    cue(st, 'whoosh');
    cue(st + 0.3, 'thud', { gain: 0.5 });
    cue(L(22), 'sparkle', { dur: 1.2, gain: 0.5 });
  }

  // ── S11 · PROBLEM #4 (Lines 23-24): Door yanked wide open mid-cycle! ──
  {
    const st = cut(23);
    add({
      id: 'S11', at: st, note: 'Hero midnight microwave: door yanked wide open mid-cycle',
      draw(lt, d, t, blit) {
        resetKitchen();
        K.pasta.group.visible = false;
        const yankK = eob(seg(lt, L(24) - st, L(24) - st + 0.55));
        K.mic.setDoorAngle(yankK * 1.15);
        K.mic.turntablePivot.rotation.y = (1 - yankK) * lt * 2.2;
        K.mic.cavityLight.intensity = 0.48;
        K.micPasta.update(t, 0.65, 0);
        const k = eio(clamp(lt / d));
        const center = V3(0.16, 1.09, -1.52);
        cam.position.copy(lerpV(V3(0.54, 1.24, -0.45), V3(0.32, 1.18, -0.68), k));
        cam.lookAt(center);
        E.render(K.scene, cam, { ...KLOOK, focus: cam.position.distanceTo(center), t });
        blit();
        if (yankK > 0.25) warning(540, 390, eob(seg(lt, L(24) - st + 0.15, L(24) - st + 0.45)) * 0.85);
      },
    });
    cue(st, 'whoosh');
    cue(L(24) + 0.1, 'slam', { gain: 0.65 });
  }

  // ── S12 · FIX #4 (Lines 25-26): Triple Interlock Switches & Fail-Safe Fuse ──
  {
    const st = cut(25);
    add({
      id: 'S12', at: st, note: 'Macro X-ray door latch micro-switches cut power, backup switch blows glass fuse',
      draw(lt, d, t, blit) {
        const k = eio(clamp(lt / d));
        const openK = eo(seg(lt, 1.4, 2.2));
        const blowStart = Wd('blows', 26) - st - 0.15;
        const fuseK = clamp(seg(lt, blowStart, blowStart + 1.1));
        SW.update(t, openK, fuseK);
        const p0 = V3(-0.08, 0.12, 1.55), p1 = V3(0.32, 0.04, 1.22);
        const l0 = V3(0.06, 0.04, 0), l1 = V3(0.36, 0.0, 0);
        cam.position.copy(lerpV(p0, p1, k));
        const target = lerpV(l0, l1, k);
        cam.lookAt(target);
        E.render(SW.scene, cam, { ...XLOOK, bloom: 0.40, focus: cam.position.distanceTo(target), t });
        blit();
        const [sx, sy] = screen(V3(0.15, 0.28, 0), cam);
        label('INTERLOCK SWITCHES', 500, 340, sx, sy, eob(seg(lt, 0.3, 0.65)));
        if (lt > blowStart - 0.3) {
          const [fx, fy] = screen(V3(0.56, 0.0, 0), cam);
          label('FAIL-SAFE FUSE', 730, 1210, fx, fy, eob(seg(lt, blowStart - 0.3, blowStart + 0.1)));
        }
      },
    });
    cue(st, 'whoosh');
    cue(st + 1.5, 'tock', { gain: 0.75 });
    cue(Wd('blows', 26) - 0.05, 'slam', { gain: 0.7 });
  }

  // ── S13 · PROBLEM #5 & FIX #5 (Lines 27-30): Magnetron Overheat -> Cooling Fins & Fan ──
  {
    const st = cut(27);
    add({
      id: 'S13', at: st, note: 'Macro copper magnetron overheating red-hot, then aluminum cooling fins & axial fan cool it down',
      draw(lt, d, t, blit) {
        const k = eio(clamp(lt / d));
        const finsAt = L(30) - st + 0.1;
        const fanAt = Wd('fan', 30) - st - 0.15;
        const finsIn = eob(seg(lt, finsAt, finsAt + 0.75));
        const fanIn = eob(seg(lt, fanAt, fanAt + 0.75));
        const heat = 1.0 - eo(seg(lt, fanAt + 0.2, d)) * 0.88;
        MAG.update(t, heat, finsIn, fanIn);

        const ang = lerp(-0.55, 0.72, k);
        const rad = lerp(1.12, 1.48, k);
        cam.position.set(Math.sin(ang) * rad, lerp(0.24, 0.34, k), Math.cos(ang) * rad);
        const target = V3(0, 0.02, -0.08 * fanIn);
        cam.lookAt(target);
        E.render(MAG.scene, cam, { ...XLOOK, bloom: 0.32, focus: cam.position.distanceTo(target), t });
        blit();
        if (lt < finsAt) {
          pill('OVERHEATING!', 540, 330, eob(seg(lt, 0.6, 0.95)), '#FF5A5A');
        } else {
          const [fx, fy] = screen(V3(0.18, 0.1, 0.08), cam);
          label('COOLING FINS + FAN', 540, 330, fx, fy, eob(seg(lt, finsAt + 0.15, finsAt + 0.55)));
        }
      },
    });
    cue(st, 'whoosh');
    cue(st + 0.8, 'alarm', { dur: 1.8, gain: 0.45 });
    cue(L(30) + 0.15, 'thud', { gain: 0.6 });
    cue(Wd('fan', 30), 'slide', { dur: 2.2, gain: 0.55 });
  }

  // ── S14 · PAYOFF REVEAL (Lines 31-32): Full Modern Microwave Oven w/ LED Clock & Keypad! ──
  {
    const st = cut(31);
    add({
      id: 'S14', at: st, note: 'Hero reveal pull-back: complete sleek modern microwave oven with glowing 01:30 display',
      draw(lt, d, t, blit) {
        resetKitchen();
        K.pasta.group.visible = false;
        K.mic.setDoorAngle(0);
        K.mic.setMeshVisible(0.82);
        K.mic.turntablePivot.rotation.y = lt * 1.4;
        K.mic.cavityLight.intensity = 0.55;
        K.micPasta.update(t, 0.7, 0);
        const k = eio(clamp(lt / d));
        // Frame the ENTIRE microwave cleanly including the glowing 01:30 keypad on the right!
        const center = V3(0.18, 1.09, -1.52);
        const p0 = V3(0.42, 1.16, -0.35), p1 = V3(0.18, 1.28, 0.22);
        cam.position.copy(lerpV(p0, p1, k));
        cam.lookAt(center);
        E.render(K.scene, cam, { ...KLOOK, focus: cam.position.distanceTo(center), t });
        blit();
        const revAt = L(32) - st + 0.45;
        if (lt > revAt) {
          pill('MICROWAVE OVEN', 540, 320, eob(seg(lt, revAt, revAt + 0.4)), '#5BF4FF', 'rgba(8,14,24,0.88)', 64);
        }
      },
    });
    cue(st, 'whoosh');
    cue(L(32) + 0.4, 'sparkle', { dur: 1.6, gain: 0.65 });
  }

  return { shots: S, cues: CUES };
}
