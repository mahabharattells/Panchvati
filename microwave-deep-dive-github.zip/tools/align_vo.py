"""Align verbatim script lines to the user's uploaded Liam voiceover using exact silencedetect segments,
writing data/lines.json, data/words.json, and preserving the untouched voiceover as 48 kHz mono data/narration.wav."""
import json, re, subprocess
from pathlib import Path

P = Path('/working_dir/c_a2e8988d82ddc09d/microwave-deep-dive')
script = json.loads((P / 'script.json').read_text())
lines = script['lines']

SEGMENTS = [
    (0.04, 2.66), (3.06, 4.55), (5.32, 8.59), (9.09, 12.45), (12.84, 14.25),
    (15.45, 15.87), (16.25, 17.67), (18.47, 19.81), (20.32, 21.72), (22.48, 25.39),
    (26.26, 26.90), (27.16, 28.01), (28.94, 29.95), (30.52, 31.50), (32.66, 34.63),
    (34.93, 37.36), (38.11, 41.39), (42.08, 42.56), (43.05, 44.64), (45.31, 47.86),
    (48.60, 51.78), (52.80, 55.34), (55.84, 57.34), (58.07, 58.73), (59.26, 61.26),
    (62.06, 63.97), (64.33, 69.47), (70.24, 71.11), (71.45, 72.71), (73.04, 73.80),
    (74.56, 78.31), (78.82, 80.15), (80.85, 83.41),
]

assert len(SEGMENTS) == len(lines), f"Segment count {len(SEGMENTS)} != lines {len(lines)}"

def weight(word):
    clean = re.sub(r'[^a-zA-Z0-9]', '', word)
    return max(2.2, len(clean) * 0.85 + 1.2)

out_lines = []
all_words = []
for i, (ln, (s0, s1)) in enumerate(zip(lines, SEGMENTS)):
    text = ln['text']
    toks = text.split()
    ws = [weight(w) for w in toks]
    tot = sum(ws)
    dur = s1 - s0
    cur = s0
    for tok, w in zip(toks, ws):
        wd = dur * (w / tot)
        all_words.append({'w': tok, 'line': i, 's': round(cur, 3), 'e': round(cur + wd, 3)})
        cur += wd
    out_lines.append({'i': i, 'text': text, 'start': round(s0, 3), 'end': round(s1, 3)})

(P / 'data' / 'lines.json').write_text(json.dumps({'duration': 84.0, 'lines': out_lines}, indent=2))
(P / 'data' / 'words.json').write_text(json.dumps(all_words, indent=2))
print(f"Wrote data/lines.json ({len(out_lines)} lines, 84.0s) and data/words.json ({len(all_words)} words)")

subprocess.run([
    'ffmpeg', '-y', '-hide_banner', '-loglevel', 'error',
    '-i', str(P / 'data' / 'vo_original.mp3'),
    '-ar', '48000', '-ac', '1', str(P / 'data' / 'narration.wav')
], check=True)
print("Wrote data/narration.wav (untouched Liam voiceover, 48 kHz)")
