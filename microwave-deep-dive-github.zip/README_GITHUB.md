# How You Accidentally Reinvented the Modern Microwave Oven — GitHub Fast-Render Guide

This project renders your full **1080×1920, 24 fps, Deep Dive 3D** video synced to your uploaded Liam voiceover (`data/mix.wav`) using **12 parallel GitHub Actions runners** (~5–8 minutes wall-clock at maximum quality, $0 on a public repo).

## Step-by-Step (2 Minutes to Start)

1. **Create a new GitHub repository** (set to **Public** for free unlimited 4-vCPU runners, or Private if you want to use your 2,000 free monthly minutes).
2. **Unzip `microwave-deep-dive-github.zip`** on your computer/phone and upload **all files and folders** (including the hidden `.github/workflows/render-video.yml` file!) to the root of your repo.
   - *Tip:* If uploading via GitHub's web UI, make sure `.github/workflows/render-video.yml` is included—or use `git push`:
     ```bash
     git init
     git add .
     git commit -m "Add Microwave Deep Dive 3D project"
     git branch -M main
     git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
     git push -u origin main
     ```
3. Open your repo on GitHub → click the **Actions** tab → select **Render Deep Dive 3D Video (12x Parallel)** on the left → click **Run workflow**.
4. Leave the default **Maximum Quality** settings (`fps: 24`, `res: 1.0`, `aa: 4`, `shadow: 2048`, `dof: true`) and click **Run workflow**.
   - *Note:* If you want an even faster ~4-minute render, set `dof: false` and `res: 0.8`.
5. Wait ~5–8 minutes for all 12 chunks + `Stitch Final 1080x1920 MP4` to turn green, then scroll down to **Artifacts** and download **`microwave-oven-deep-dive-3d`** (`microwave-oven-deep-dive-3d.mp4`).
