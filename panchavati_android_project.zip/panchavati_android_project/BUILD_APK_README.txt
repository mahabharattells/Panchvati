Panchavati 3D Open World — How to Build Your Installable .APK
=============================================================

Option 1 (Android Studio — Recommended, Free):
1. Unzip panchavati_android_project.zip and open the folder in Android Studio.
2. Wait for Gradle sync to finish.
3. Click Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. Copy app/build/outputs/apk/debug/app-debug.apk to your Android phone and install!

Option 2 (Quick No-Code Web-to-APK):
- Upload app/src/main/assets/index.html directly to any HTML-to-APK wrapper tool
  (such as Capacitor, Cordova, or Website 2 APK Builder) with Landscape orientation
  and Hardware Acceleration enabled.
