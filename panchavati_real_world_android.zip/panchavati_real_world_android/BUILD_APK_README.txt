Panchavati Real-Map 3D Open World — How to Build Your .APK
==========================================================
1. Unzip panchavati_real_world_android.zip and open the folder in Android Studio.
2. Wait for Gradle sync to finish.
3. Click Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. Install app/build/outputs/apk/debug/app-debug.apk on your Android phone!
